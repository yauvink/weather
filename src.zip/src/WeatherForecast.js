import React from 'react';
//import './index.css';
import Select from 'react-select'


//http://api.openweathermap.org/data/2.5/forecast?id=625144&appid=dd85eb16c341cc88fed125ccfa1e9fdb

class WeatherForecast extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            error: null,
            isLoaded: false,
            data: {},
            cities: [
                { label: 'Minsk', value: '625144' },
                { label: 'Moscow', value: '524901' },
                { label: 'Kiev', value: '703448' } 
            ],
            selectedCity: ""
        };

        this.handleSelectChange = this.handleSelectChange.bind(this);
        // this.getWeatherData = this.getWeatherData.bind(this);
    }
   
    componentDidMount() {
        console.log(this.state.selectedCity)
        console.log(typeof this.state.selectedCity)
        this.setState({
            selectedCity: "625144"
        })
       
    }
    // getWeatherData(){
    //      fetch(`http://api.openweathermap.org/data/2.5/forecast?id=${this.state.selectedCity}&appid=dd85eb16c341cc88fed125ccfa1e9fdb`)
    //     .then(res => res.json())
    //     .then(
    //         (result) => {
    //             // this.setState({
    //             //     isLoaded: true,
    //             //     data: result
    //             // });
    //             console.log(this.state.data)
    //         },
    //         (error) => {
    //             // this.setState({
    //             //     isLoaded: true,
    //             //     error
    //             // });
    //         }
    //     )
    // }
    componentDidUpdate(){
    //    if(this.state.selectedCity != ""){
    //     fetch(`http://api.openweathermap.org/data/2.5/forecast?id=${this.state.selectedCity}&appid=dd85eb16c341cc88fed125ccfa1e9fdb`)
    //     .then(res => res.json())
    //     .then(
    //         (result) => {
    //             this.setState({
    //                 isLoaded: true,
    //                 data: result
    //             });
    //             //console.log(this.state.data)
    //         },
    //         (error) => {
    //             this.setState({
    //                 isLoaded: true,
    //                 error
    //             });
    //         }
    //     )
    //    }
    }

    handleSelectChange(e){
        this.setState({
            selectedCity: e.value
        })

        console.log(this.state.selectedCity)
    }

    render() {
        console.log("render")
        console.log(this.selectedCity)
        const { error, isLoaded } = this.state;
        // if (error) {
        //     return <div>Error: {error.message}</div>;
        // } else if (!isLoaded) {
        //     return <div>Loading...</div>;
        // } else {
        
                return (
                    
                    <div>
                        <h2>data loaded</h2>
                        <Select id="citySelect" onChange={this.handleSelectChange} options={this.state.cities} />
    
                        <h4>{this.state.selectedCity}</h4>
                        {/* <ul>
                            {data.list.map(item => (
                                <li key={item.name}>
                                    {item.dt} {item.dt}
                                </li>
                            ))}
                        </ul> */}
                        
                    </div>
                )          
    }

    
}

export default WeatherForecast;

class App extends React.Component {

    constructor(props){
      super(props)
      this.state = {
        selectOptions : [],
        id: "",
        name: ''
      }
    }
  
   async getOptions(){
      const res = await axios.get('https://jsonplaceholder.typicode.com/users')
      const data = res.data
  
      const options = data.map(d => ({
        "value" : d.id,
        "label" : d.name
  
      }))
  
      this.setState({selectOptions: options})
  
    }
  
    handleChange(e){
     this.setState({id:e.value, name:e.label})
    }
  
    componentDidMount(){
        this.getOptions()
    }
  
    render() {
      console.log(this.state.selectOptions)
      return (
        <div>
          <Select options={this.state.selectOptions} onChange={this.handleChange.bind(this)} />
      <p>You have selected <strong>{this.state.name}</strong> whose id is <strong>{this.state.id}</strong></p>
        </div>
      )
    }
  }