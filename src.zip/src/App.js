import React from 'react';
import './App.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import WeatherForecast from "./WeatherForecast"

//http://api.openweathermap.org/data/2.5/forecast?id=625144&appid=dd85eb16c341cc88fed125ccfa1e9fdb


function App() {
  return (
    <div className="App">
      <div>
        <h1>Weather</h1>
      </div>
      <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/WeatherForecast">Weather Forecast</Link>
            </li>
            <li>
              <Link to="/WeatherSchedule">Weather Schedule</Link>
            </li>
          </ul>
        </nav>

        <Switch>
          <Route path="/WeatherSchedule">
            <WeatherSchedule />
          </Route>
          <Route path="/WeatherForecast">
            <WeatherForecast />
          </Route>
        </Switch>
      </div>
    </Router>
    </div>
  );
}


function WeatherSchedule() {
  return <h2>Weather Schedule</h2>;
}
export default App;
